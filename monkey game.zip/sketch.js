var ground,jungle,stone,banana,monkey;
var bananaGroup,stoneGroup,count;

function preload(){
count = 0;  
  bananaimg = loadImage("Banana.png");
  stoneimg = loadImage("stone.png");
  groundimg = loadImage("ground.jpg"); 
jungleimg = loadImage("jungle.jpg");
monkeyimg =loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
} 



function setup() {
  createCanvas(600,500);

  //set ground
  ground = createSprite(100,550,10,10);
 ground.addImage(groundimg); 
  ground.scale = 0.3;
  ground.visible = false;

  //SET BACKGROUND
  jungle = createSprite(500,200,10,10); 
  jungle.addImage(jungleimg);
 jungle.velocityX = -5; 
  
  //setting monkeys
  monkey = createSprite(100,500,10,10);
monkey.addAnimation("running",monkeyimg);
  monkey.scale = 0.1;

  stoneGroup = new Group();
bananaGroup = new Group();  

}


function draw(){
 background(255); 
textSize(30);
fill("white"); 


  if(monkey.isTouching(bananaGroup)){
 bananaGroup.destroyEach();
  count = count+2;
} 
  if(keyDown("space")&&monkey.y>320){
  monkey.velocityY = -17 ;
  }
    if(jungle.x<100){
 jungle.x = jungle.width/2 ;
 }
if(stoneGroup.isTouching(monkey)){
   monkey.scale = 0.1;
   
  
   }   

    
  
switch(count){
  case 10:
 monkey.scale = 0.12;   
  break;  
  case 20:
 monkey.scale = 0.14;   
  break;   
    case 30:
 monkey.scale = 0.16;   
  break; 
    case 40:
 monkey.scale = 0.18;   
  break; 
  default: break;   
    
} 
if(jungle.x<100){
 jungle.x = jungle.width/2 ;
  
} 

//add gravity  
  monkey.velocityY = monkey.velocityY+0.8;
monkey.collide(ground);  
 spawnbanana();
  spawnStone();
  drawSprites();
text("score  ="+count,100,50);  

}



function spawnStone(){
if(frameCount%150 === 0){
    stone = createSprite(640,380,10,10);  
   stone.addImage(stoneimg); 
stone.velocityX = -8;   
stone.scale = 0.2;
 stone.lifetime = 100; 
  stoneGroup.add(stone);
}
}
function spawnbanana(){
if(frameCount%100 === 0){
   banana = createSprite(640,200,10,10);  
 banana.addImage(bananaimg);
  banana.scale = 0.1;
 banana.velocityX = -8; 
  banana.lifetime = 100;
 bananaGroup.add(banana);
}
  
  
  
} 









